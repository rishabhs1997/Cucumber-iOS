package stepDefinations;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.lexer.Th;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import resources.Utility;

import java.util.concurrent.TimeUnit;

/**
 * Created by rishabh.sakhare on 8/1/2019.
 */
public class PrimaryConsent extends Utility {

    @When("^i complete primary consent$")
    public void i_complete_primary_consent() throws InterruptedException {

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

    //1st PC - Welcome
        completeVideo();
        tap(driver);
        clickNext(driver);

    //2st PC - Are you Ready?
        clickNext(driver);

    //3rd PC - Just so u know
        clickNext(driver);

    //4th PC - Your about to make history
        Thread.sleep(3000);
        Utility.scroll2();
        clickNext(driver);

    //5th PC - Where you live
        driver.findElementByName("state").click();
        tapDone(driver);
        driver.findElementByName("Done").click();
        clickNext(driver);

    //6th PC - Before we begin
        driver.findElementByAccessibilityId("YesRadio button").click();
        clickNext(driver);

    //7th PC - Where u get Healthcare
        driver.findElementByName("state").click();
        tapDone(driver);
        driver.findElementByName("Done").click();
        clickNext(driver);

    //8th PC - Chech your Understanding
        clickNext(driver);

    //9th PC - What will I do
        clickNext(driver);

    //10th PC - Keeping in Touch
        completeVideo();
        tap(driver);
        Thread.sleep(3000);
        Utility.scroll2();
        clickNext(driver);

    //11th PC - Health Data
        completeVideo();
        tap(driver);
        clickNext(driver);

    //12th PC - Health Record

        completeVideo();
        tap(driver);
        clickNext(driver);

    //13th PC - Physical Measurement
        completeVideo();
        tap(driver);
        clickNext(driver);

    //14th PC - Samples
        completeVideo();
        Thread.sleep(4000);
        tap(driver);
        clickNext(driver);

    //15th PC - DNA Analysis
        completeVideo();
        Thread.sleep(2000);
        tap(driver);
        clickNext(driver);

    //16th PC - Fitness Tracker
        completeVideo();
        tap(driver);
        clickNext(driver);

    //17th PC - Other Health Data
        completeVideo();
        tap(driver);
        clickNext(driver);

    //18th PC - What will we do?
        clickNext(driver);

    //19th PC - Data Sharing
        completeVideo();
        tap(driver);
        clickNext(driver);

    //20th PC - Potential Benefits
        clickNext(driver);

    //21th PC - Other Benefits
        clickNext(driver);

    //22th PC - Risk to Privacy
        completeVideo();
        Thread.sleep(4000);
        tap(driver);
        clickNext(driver);

    //23th PC - Not Medical Care
        clickNext(driver);

    //24th PC - You get to choose
        clickNext(driver);

    //25th PC - If you Withdraw
        clickNext(driver);

    //26th PC - Think it over
        clickNext(driver);

    //27th PC - Next for Longscroll
        clickNext(driver);

    //28th PC - Consent to Join
        Thread.sleep(2000);
        for(int i=0;i<14;i++) {
            Utility.scrollLong();
        }
        clickNext(driver);

    //29th PC - Are you ready?
        clickNext(driver);

    //30th PC - Quiz
        driver.findElementByXPath("//*[contains(@name,'researchers')]").click();
        clickNext(driver);

    //31st PC
        driver.findElementByXPath("//*[contains(@name,'voluntary')]").click();
        clickNext(driver);

    //32nd PC
        driver.findElementByXPath("//*[contains(@name,'time')]").click();
        clickNext(driver);

    //33rd PC -
        driver.findElementByXPath("//*[contains(@name,'Risks')]").click();
        clickNext(driver);

    //34th PC
        driver.findElementByXPath("//*[contains(@name,'ready')]").click();
        clickNext(driver);

    //35th PC - Statement
        driver.findElementByAccessibilityId("Boolean Selector").click();
        clickNext(driver);

    //36th PC - Name, date, scroll
        driver.findElementByXPath("//*[contains(@name,'full')]").sendKeys("Anyname Surname");
        Utility.scroll2();
        driver.findElementByXPath("//*[contains(@name,'date')]").click();
        Thread.sleep(2000);
        clickNext(driver);

    //37th PC - Click no
        driver.findElementByAccessibilityId("NoRadio button").click();
        clickNext(driver);

    //38th PC - Scroll
        Thread.sleep(3000);
        Utility.scroll2();
        driver.findElementByAccessibilityId("first name").sendKeys("AnyFirst");
        driver.findElementByAccessibilityId("middle initial").sendKeys("M");
        driver.findElementByAccessibilityId("last name").sendKeys("AnyLast");
        driver.hideKeyboard();

        String path = "address 1";
        driver.findElementByAccessibilityId(path).click();
        if((driver.findElementByAccessibilityId(path)).isDisplayed()) {
            driver.findElementByAccessibilityId(path).sendKeys("Anyaddress");
            driver.hideKeyboard();
        }


//      driver.findElementByXPath("/*//*[contains(@name,'address 2')]").sendKeys("AnyAddress 2");
        driver.hideKeyboard();

        Utility.scroll2();

        driver.findElementByAccessibilityId("city").sendKeys("AnyCity");
        driver.hideKeyboard();

        driver.findElementByAccessibilityId("state").click();
        tapDone(driver);
        driver.findElementByName("Done").click();

        path = "zip code";
        String zip = "45678";
        driver.findElementByAccessibilityId(path).sendKeys(zip);
        driver.hideKeyboard();

        path = "phone number";
        String no = "9999999999";
        driver.findElementByAccessibilityId(path).click();
        driver.findElementByAccessibilityId(path).sendKeys(no);


        driver.hideKeyboard();

        driver.findElementByAccessibilityId("MM/DD/YYYY").click();
        Thread.sleep(2000);
        for(int i=0; i<10; i++) {
            scrollShort();
        }

        //driver.findElementById("com.acadia.pmistaging:id/date_picker_done").click();
        tapLastDone();

        clickNext(driver);

    //39th PC
        driver.findElementByAccessibilityId("Submit").click();

     //40th PC
        driver.findElementByAccessibilityId("Yes").click();


    }

    @Then("^display dashboard$")
    public void display_dashboard() {
        System.out.println("\n DASHBOARD OPENED !!");
    }
}
