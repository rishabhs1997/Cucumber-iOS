package resources;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

/**
 * Created by rishabh.sakhare on 7/26/2019.
 */
public class Utility {

    public static IOSDriver<MobileElement> driver;

    static String existinguserEmail="vignetTest25@gmail.com",userEmail="vignetTest26@gmail.com",invaliduserEmail="vignet";
    static String userPass="Aa@12345";
    static int driverflag = 0;

    public WebDriverWait wait = new WebDriverWait(driver,15);


    public static int setDriver() throws MalformedURLException {
        DesiredCapabilities cap = new DesiredCapabilities();

//iPhone 5

       /* cap.setCapability("deviceName", "VIG-262");
        cap.setCapability("udid", "886541b30ae399cd9b456ce2ff10b84ee7461dda");
        cap.setCapability("platformName", "iOS");
        cap.setCapability("platformVersion", "10.3.4");
        cap.setCapability("automationName", "XCUITest");
        cap.setCapability("bundleId", "com.vibrent.PMI");
       */ //cap.setCapability("bundleId", "com.apple.reminders");

        //cap.setCapability( "xcodeOrgId", "Karma");
        //cap.setCapability("xcodeSigningId","iPhone Developer");
        //cap.setCapability("appiumVersion", "1.13.0");


//Simulator

        cap.setCapability("deviceName", "iPhone XS");
        cap.setCapability("udid", "19A5134C-D0E9-49DB-8CB6-FD812A2849B3");
        cap.setCapability("platformName", "iOS");
        cap.setCapability("platformVersion", "12.1");
        cap.setCapability("automationName", "XCUITest");
        cap.setCapability("app","/Users/rishabh.sakhare/Downloads/PMIIPA-16.zip");
        //cap.setCapability("fullReset","true");
        //cap.setCapability("connectHardwareKeyboard", false);
        //cap.setCapability("bundleId", "com.vibrent.PMI");


        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        driver = new IOSDriver<MobileElement>(url,cap);

        System.out.println("Application Started!! ");
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        return 1;
    }





    //Generic function for Scroll
    public static void scroll2() {
        TouchAction actions = new TouchAction(driver);
        actions.press(PointOption.point(390, 470))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
                .moveTo(PointOption.point(390, 70)).release().perform();
    }



    //Generic function for Scroll
    public static void scrollLong() {
        TouchAction actions = new TouchAction(driver);
        actions.press(PointOption.point(300, 660))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
                .moveTo(PointOption.point(300, 200)).release().perform();
    }

    //Generic function for short Scroll
    public static void scrollShort() {
        TouchAction actions = new TouchAction(driver);
        actions.press(PointOption.point(330, 620))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(4)))
                .moveTo(PointOption.point(330, 760)).release().perform();
    }


    public void tap(IOSDriver driver) {

        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("All of Us")));
        TouchAction action = new TouchAction(driver);
            action.tap(PointOption.point(240, 750)).perform();
            if((driver.findElementByAccessibilityId("Next").getAttribute("value")).equals("0"))
            {
                tap(driver);
            }
    }

    public void clickNext(IOSDriver driver) throws InterruptedException {

        Thread.sleep(500);
        driver.findElementByAccessibilityId("Next").click();
    }

    public void completeVideo() throws InterruptedException {
        Thread.sleep(1000);
        MobileElement button = (MobileElement) driver.findElementByAccessibilityId("play button");
        wait.until(ExpectedConditions.visibilityOf(button));
        button.click();
    }


    public void tapDone(IOSDriver driver) {

        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("All of Us")));
        TouchAction action = new TouchAction(driver);
        action.tap(PointOption.point(240, 750)).perform();
    }


    public void tapLastDone() {

        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("All of Us")));
        TouchAction action = new TouchAction(driver);
        action.tap(PointOption.point(340, 570)).perform();

    }


    public static IOSDriver getDriver() throws MalformedURLException {

        if(driverflag == 0) {
            driverflag = setDriver();
        }

        if(driver.isDeviceLocked())
        {
            driver.unlockDevice();
        }

        return driver;
    }

    public static String getUserEmail()
    {
        return userEmail;
    }

    public static String getExistinguserEmail()
    {
        return existinguserEmail;
    }

    public static String getInvaliduserEmail()
    {
        return invaliduserEmail;
    }

    public static String getUserPass()
    {
        return userPass;
    }

}

